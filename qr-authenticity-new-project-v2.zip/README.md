# QR Authenticity — مشروع جديد

## الفكرة
كل الملصقات تحمل **نفس QR**. الـQR يفتح صفحة التحقق العامة. المعلومات لا يحددها الـQR؛ بل يحددها **الكود السري المخفي تحت الخدش**.

التدفق:
1. الزبون يمسح QR.
2. يفتح `/`.
3. يدخل الكود السري.
4. النظام يستدعي `verify_qr_code`.
5. الكود الصحيح وغير المستخدم = PRODUIT ORIGINAL ويتم تحويله فورًا إلى USED.
6. الكود المستعمل = CODE DÉJÀ UTILISÉ.
7. الكود الخاطئ = PRODUIT NON ORIGINAL.

## إعداد Vercel
أضف Environment Variables:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

القيم الخاصة بالمشروع موجودة في `.env.example` (استبدلها عند الحاجة).

## ملاحظة مهمة
النسخة الحالية تستخدم Supabase Auth للوحة الإدارة. صلاحيات RLS الحالية في مشروع Supabase تسمح للمستخدم authenticated بإدارة سجلات `qr_codes`. في الإنتاج يفضّل إضافة جدول أدوار Admin وتقييد الصلاحيات.

## قاعدة البيانات
استخدم SQL الذي تم تنفيذه في Supabase في هذه المحادثة، بما فيه وظيفة `verify_qr_code`.

## QR
الـQR المطبوع هو نفس رابط الصفحة:
`https://YOUR-VERCEL-DOMAIN.vercel.app/`

لا يتم وضع secret code داخل QR.
