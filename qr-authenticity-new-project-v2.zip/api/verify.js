const { createClient } = require("@supabase/supabase-js");

module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");

  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { qr_id = "MAIN", secret_code } = req.body || {};
  if (!secret_code || typeof secret_code !== "string") {
    return res.status(400).json({ success: false, status: "invalid" });
  }

  const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_ANON_KEY,
    { auth: { persistSession: false } }
  );

  const { data, error } = await supabase.rpc("verify_qr_code", {
    p_qr_id: String(qr_id),
    p_secret_code: secret_code.trim().toUpperCase()
  });

  if (error) {
    console.error(error);
    return res.status(500).json({ success: false, status: "server_error" });
  }

  return res.status(200).json(data);
};
